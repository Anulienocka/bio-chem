# Môj test

Jednoduchá bezplatná webová aplikácia pre mobil aj počítač.

## Funkcie
- ručné pridávanie otázok
- 8 možností A–H
- viac správnych odpovedí
- obrázok pri otázke
- vysvetlenie odpovede
- náhodné otázky
- režim 4 alebo 8 možností
- vyhodnotenie a percentá
- export/import databázy otázok
- dáta sa ukladajú v prehliadači

## Poznámka k režimu 4 možností
Ak má otázka viac ako 4 správne odpovede, nie je matematicky možné zobraziť iba 4 možnosti a zároveň zobraziť všetky správne odpovede. Také otázky sa preto v 4-možnostovom režime vynechajú.
